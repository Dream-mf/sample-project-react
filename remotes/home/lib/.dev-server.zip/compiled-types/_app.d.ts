declare const App: () => any;
export default App;
//# sourceMappingURL=_app.d.ts.map