declare const Health: () => JSX.Element;
export default Health;
//# sourceMappingURL=_health.d.ts.map