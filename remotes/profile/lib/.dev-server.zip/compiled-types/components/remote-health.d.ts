interface ReactHealthProps {
    name: string;
    version: string;
    dependencies: any;
}
export declare const RemoteHealthComponent: ({ name, version, dependencies }: ReactHealthProps) => JSX.Element;
export {};
//# sourceMappingURL=remote-health.d.ts.map