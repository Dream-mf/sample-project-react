import React from "react";
interface LayoutProps {
    children: React.ReactNode;
}
declare const CustomLayout: ({ children }: LayoutProps) => JSX.Element;
export default CustomLayout;
//# sourceMappingURL=index.d.ts.map