declare const Health: () => any;
export default Health;
//# sourceMappingURL=_health.d.ts.map