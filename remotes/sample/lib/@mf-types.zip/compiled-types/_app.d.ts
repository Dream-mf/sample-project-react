declare const Sample: ({ id }: {
    id: any;
}) => any;
export default Sample;
//# sourceMappingURL=_app.d.ts.map